# basic-linux-setup-installer

Another installation method for the configuration.

basic-linux-setup
https://github.com/thanasxda
15927885+thanasxda@users.noreply.github.com
https://github.com/thanasxda/basic-linux-setup.git

