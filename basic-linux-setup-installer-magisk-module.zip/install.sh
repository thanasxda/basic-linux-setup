##########################################################################################
#
# Magisk Module Installer Script
#
##########################################################################################
##########################################################################################
#
# Instructions:
#
# 1. Place your files into system folder (delete the placeholder file)
# 2. Fill in your module's info into module.prop
# 3. Configure and implement callbacks in this file
# 4. If you need boot scripts, add them into common/post-fs-data.sh or common/service.sh
# 5. Add your additional or modified system properties into common/system.prop
#
##########################################################################################

##########################################################################################
# Config Flags
##########################################################################################

# Set to true if you do *NOT* want Magisk to mount
# any files for you. Most modules would NOT want
# to set this flag to true
SKIPMOUNT=false

# Set to true if you need to load system.prop
PROPFILE=false

# Set to true if you need post-fs-data script
POSTFSDATA=false

# Set to true if you need late_start service script
LATESTARTSERVICE=true

##########################################################################################
# Replace list
##########################################################################################

# List all directories you want to directly replace in the system
# Check the documentations for more info why you would need this

# Construct your list in the following format
# This is an example
REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here
REPLACE="
"

##########################################################################################
#
# Function Callbacks
#
# The following functions will be called by the installation framework.
# You do not have the ability to modify update-binary, the only way you can customize
# installation is through implementing these functions.
#
# When running your callbacks, the installation framework will make sure the Magisk
# internal busybox path is *PREPENDED* to PATH, so all common commands shall exist.
# Also, it will make sure /data, /system, and /vendor is properly mounted.
#
##########################################################################################
##########################################################################################
#
# The installation framework will export some variables and functions.
# You should use these variables and functions for installation.
#
# ! DO NOT use any Magisk internal paths as those are NOT public API.
# ! DO NOT use other functions in util_functions.sh as they are NOT public API.
# ! Non public APIs are not guranteed to maintain compatibility between releases.
#
# Available variables:
#
# MAGISK_VER (string): the version string of current installed Magisk
# MAGISK_VER_CODE (int): the version code of current installed Magisk
# BOOTMODE (bool): true if the module is currently installing in Magisk Manager
# MODPATH (path): the path where your module files should be installed
# TMPDIR (path): a place where you can temporarily store files
# ZIPFILE (path): your module's installation zip
# ARCH (string): the architecture of the device. Value is either arm, arm64, x86, or x64
# IS64BIT (bool): true if $ARCH is either arm64 or x64
# API (int): the API level (Android version) of the device
#
# Availible functions:
#
# ui_print <msg>
#     print <msg> to console
#     Avoid using 'echo' as it will not display in custom recovery's console
#
# abort <msg>
#     print error message <msg> to console and terminate installation
#     Avoid using 'exit' as it will skip the termination cleanup steps
#
# set_perm <target> <owner> <group> <permission> [context]
#     if [context] is empty, it will default to "u:object_r:system_file:s0"
#     this function is a shorthand for the following commands
#       chown owner.group target
#       chmod permission target
#       chcon context target
#
# set_perm_recursive <directory> <owner> <group> <dirpermission> <filepermission> [context]
#     if [context] is empty, it will default to "u:object_r:system_file:s0"
#     for all files in <directory>, it will call:
#       set_perm file owner group filepermission context
#     for all directories in <directory> (including itself), it will call:
#       set_perm dir owner group dirpermission context
#
##########################################################################################
##########################################################################################
# If you need boot scripts, DO NOT use general boot scripts (post-fs-data.d/service.d)
# ONLY use module scripts as it respects the module status (remove/disable) and is
# guaranteed to maintain the same behavior in future Magisk releases.
# Enable boot scripts by setting the flags in the config section above.
##########################################################################################

# Set what you want to display when installing your module
vers="$(grep version= $TMPDIR/module.prop | awk -F = '{print $2}')"
print_modname() {
  ui_print ''
  ui_print '==============================================='
  ui_print '       $$\      $$\ $$\       $$\   $$\        '
  ui_print '       $$$\    $$$ |$$ |      $$ |  $$ |       '
  ui_print '       $$$$\  $$$$ |$$ |      \$$\ $$  |       '
  ui_print '       $$\$$\$$ $$ |$$ |       \$$$$  /        '
  ui_print '       $$ \$$$  $$ |$$ |       $$  $$<         '
  ui_print '       $$ |\$  /$$ |$$ |      $$  /\$$\        '
  ui_print '       $$ | \_/ $$ |$$$$$$$$\ $$ /  $$ |       '
  ui_print '       \__|     \__|\________|\__|  \__|       '
  ui_print '                                               '
  ui_print '          basic-linux-setup-installer          '
  ui_print '                   version:                    '
      echo "                     $vers                     "
  ui_print '                   edition:                    '
  ui_print '    The fastest way to mess up your device     '
  ui_print '==============================================='
  ui_print ''
}

# Copy/extract your module files into $MODPATH in on_install.

on_install() {
  # The following is the default implementation: extract $ZIPFILE/system to $MODPATH
  # Extend/change the logic to whatever you want
if [ -e /data/adb/service.d/init.sh ] && [ -e /data/adb/service.d/blsinstaller.sh ] ; then
echo "basic-linux-setup is already installed on your system..."
echo "Setup will exit..."
exit 0 ; fi
echo "" ; echo "Bricking your device as we speak..." ; echo ""
echo "Installing basic-linux-setup-installer version: $vers" ; echo ""
if [ -e /system/xbin/sh ] ; then echo "Busybox binaries found in '/system/xbin'" ; else
echo "No Busybox binaries found in '/system/xbin'"
echo "It's recommended to install Busybox NDK module from osm0sis."
echo "Setup will continue nevertheless..."
echo "and will use the the binaries located in '/system/bin'..."
echo "till you update them." 
fi
echo ""
echo "Since progress goes slow..."
echo "and the script is still in its alpha phase."
echo "Feel free to read the README for more information on:"
echo "github.com/thanasxda/basic-linux-setup"
echo "Further information can be found in the scripts." 
echo "Located at:"
echo "'/data/adb/service.d/init.sh' post installation."
echo ""
echo '#!/system/bin/sh -x
#############################################################
#############################################################
##                  basic-linux-setup                      ##
#############################################################
##             https://github.com/thanasxda                ##
#############################################################
##      15927885+thanasxda@users.noreply.github.com        ##
#############################################################
##    https://github.com/thanasxda/basic-linux-setup.git   ##
#############################################################
#############################################################

# magisk module:
# basic-linux-setup-installer
# version: '"$vers"'

export firstrun=yes
if [ -f /sbin/sh ] ; then export bb="/sbin/" ; fi 
if [ -f /bin/sh ] ; then export bb="/bin/" ; fi 
if [ -f /system/bin/sh ] ; then export bb="/system/bin/" ; fi 
if [ -f /system/xbin/sh ] ; then export bb="/system/xbin/" ; fi 
rm -rf /data/adb/service.d/tmp
if [ -e /data/adb/service.d/init.sh ] ; then exit 0 ; else
while [ ! -f /data/adb/service.d/tmp/init.sh ] ; do
sleep 10 ; ping -c3 8.8.8.8
if [ $? -eq 0 ]; then 
"$bb"mount -o remount,rw /data
cd /data/adb/service.d ; mkdir -p tmp ; cd tmp
"$bb"wget https://raw.githubusercontent.com/thanasxda/basic-linux-setup/master/init.sh ; fi
if [ -e /data/adb/service.d/tmp/init.sh ] ; then 
chmod 755 /data/adb/service.d/tmp/init.sh
chmod +x /data/adb/service.d/tmp/init.sh 
"$bb"sh -x /data/adb/service.d/tmp/init.sh
cd /data/adb/service.d ; rm -rf tmp ; echo "succes"
exit 0 ; fi ; done ; fi' | tee /data/adb/service.d/blsinstaller.sh >/dev/null
chmod 755 /data/adb/service.d/blsinstaller.sh
chmod +x /data/adb/service.d/blsinstaller.sh
echo "Setup finished a reboot is needed..."
echo "while being connected to the internet."
echo "The installer will fetch the updated setup..."
echo "from the repository."
echo "The first run of the setup will take a bit to finish."
echo "Once installed it's recommended to reboot once more."
echo ""
echo "If something goes wrong the setup makes backups in:"
echo "'/system/etc/bak/*'"
echo "These can be copied manually to the root partition..."
echo "as they are within their subdirectories."
echo "The script has configurable variables..."
echo "allowing full uninstallation this way."
echo ""
echo "Still a work in progress, hope you enjoy..."
echo ""
echo "Ready to reboot.."
echo ""
}

# Only some special files require specific permissions
# This function will be called after on_install is done
# The default permissions should be good enough for most cases

set_permissions() {
  # The following is the default rule, DO NOT remove
  set_perm_recursive $MODPATH 0 0 0755 0644

  # Here are some examples:
  # set_perm_recursive  $MODPATH/system/lib       0     0       0755      0644
  # set_perm  $MODPATH/system/bin/app_process32   0     2000    0755      u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0     2000    0755      u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0     0       0644
}

# You can add more functions to assist your custom script code
